/* ---------- script.js (Option A: central JS) ----------
   Features:
   - Accordion
   - Service search filter
   - Lightbox gallery
   - Dynamic posts loader (index)
   - Form validation (contact + enquiry)
   - AJAX submission (fetch) with fallback to mailto
   - Small animation utilities and accessibility improvements
-------------------------------------------------------- */

(function () {
  'use strict';

  /* ==========================
     Configuration - edit these
     ========================== */
  const CONFIG = {
    contactEndpoint: '/submit-contact',   // replace with your server endpoint (or leave blank to use mailto)
    enquiryEndpoint: '/submit-enquiry',   // replace with your server endpoint (or leave blank to use modal + no back-end)
    fallbackMailTo: 'bothobodiramotho@gmail.com',
    currencySymbol: 'R'
  };

  /* ==========================
     Small utility helpers
     ========================== */
  const $ = (sel, ctx = document) => ctx.querySelector(sel);
  const $$ = (sel, ctx = document) => Array.from(ctx.querySelectorAll(sel));
  const showElement = (el) => { if (!el) return; el.style.display = ''; el.removeAttribute('hidden'); };
  const hideElement = (el) => { if (!el) return; el.style.display = 'none'; el.setAttribute('hidden', ''); };
  const setText = (el, text) => { if (!el) return; el.textContent = text; };

  /* ==========================
     Accordion (services page)
     ========================== */
  function initAccordion() {
    const items = $$('.accordion .item');
    if (!items.length) return;
    items.forEach(item => {
      const btn = item.querySelector('button');
      const panel = btn.nextElementSibling;
      // Ensure ARIA attributes present
      btn.setAttribute('aria-expanded', 'false');
      btn.addEventListener('click', () => {
        const expanded = btn.getAttribute('aria-expanded') === 'true';
        btn.setAttribute('aria-expanded', String(!expanded));
        if (expanded) {
          panel.hidden = true;
        } else {
          panel.hidden = false;
        }
      });
    });
  }

  /* ==========================
     Search filter for services
     ========================== */
  function initServiceSearch() {
    const search = $('#search');
    if (!search) return;
    search.addEventListener('input', (e) => {
      const q = e.target.value.trim().toLowerCase();
      const items = $$('.accordion .item');
      items.forEach(item => {
        const keywords = (item.dataset.keywords || '') + ' ' + item.textContent;
        const show = !q || keywords.toLowerCase().includes(q);
        item.style.display = show ? '' : 'none';
      });
    });
  }

  /* ==========================
     Lightbox gallery
     ========================== */
  function initGallery() {
    const gallery = $('#gallery');
    if (!gallery) return;
    // create lightbox element if not present
    let lightbox = $('#lightbox');
    if (!lightbox) {
      lightbox = document.createElement('div');
      lightbox.id = 'lightbox';
      lightbox.setAttribute('role', 'dialog');
      lightbox.setAttribute('aria-hidden', 'true');
      lightbox.style.display = 'none';
      lightbox.style.position = 'fixed';
      lightbox.style.inset = '0';
      lightbox.style.background = 'rgba(0,0,0,.8)';
      lightbox.style.alignItems = 'center';
      lightbox.style.justifyContent = 'center';
      lightbox.style.zIndex = '9999';
      lightbox.innerHTML = '<img alt="" style="max-width:90%;max-height:85%"><button aria-label="Close" style="position:absolute;top:1rem;right:1rem;">✕</button>';
      document.body.appendChild(lightbox);
    }
    const lbImg = lightbox.querySelector('img');
    const lbClose = lightbox.querySelector('button');

    gallery.addEventListener('click', (e) => {
      const img = e.target.closest('img');
      if (!img) return;
      lbImg.src = img.dataset.full || img.src;
      lbImg.alt = img.alt || '';
      lightbox.style.display = 'flex';
      lightbox.setAttribute('aria-hidden', 'false');
      lbClose.focus();
    });

    function closeLB() {
      lightbox.style.display = 'none';
      lightbox.setAttribute('aria-hidden', 'true');
      lbImg.src = '';
    }

    lightbox.addEventListener('click', (e) => {
      if (e.target === lightbox) closeLB();
    });
    lbClose.addEventListener('click', closeLB);
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeLB(); });
  }

  /* ==========================
     Dynamic content loader (index posts demo)
     ========================== */
  function initDynamicPosts() {
    const postsEl = $('#posts');
    if (!postsEl) return;
    // sample/local data - in real site you'd fetch('/posts.json')
    const posts = [
      { id: 1, title: 'Winter clothing drive', date: '2025-06-10', summary: 'Collecting warm clothes for children.' },
      { id: 2, title: 'After-school tutoring starts', date: '2025-07-01', summary: 'Free homework help every weekday.' }
    ];
    posts.forEach(p => {
      const article = document.createElement('article');
      article.innerHTML = `<h3>${escapeHtml(p.title)}</h3><time datetime="${p.date}">${p.date}</time><p>${escapeHtml(p.summary)}</p>`;
      postsEl.appendChild(article);
    });
  }

  function escapeHtml(str = '') {
    return str.replace(/[&<>"']/g, (m) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  }

  /* ==========================
     Form utilities & validation
     ========================== */

  // Generic: display feedback in an element (id or element), type 'error'|'success'|'info'
  function showFeedback(target, message, type = 'error') {
    let el = (typeof target === 'string') ? document.getElementById(target) : target;
    if (!el) {
      console.warn('Feedback target not found', target);
      return;
    }
    el.innerHTML = '';
    const p = document.createElement('p');
    p.textContent = message;
    p.className = type === 'error' ? 'error' : (type === 'success' ? 'success' : 'info');
    el.appendChild(p);
  }

  // Validate phone using simple pattern: + optional and 7-15 digits
  function validPhone(phone) {
    if (!phone) return true; // optional
    return /^\+?\d{7,15}$/.test(phone.trim());
  }

  /* ---------- Contact Form ---------- */
  function initContactForm() {
    const form = document.getElementById('contactForm');
    if (!form) return;

    const feedback = document.getElementById('formFeedback') || document.createElement('div');
    feedback.id = 'formFeedback';
    form.appendChild(feedback);

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      feedback.innerHTML = '';
      // Built-in HTML5 constraint check
      if (!form.checkValidity()) {
        const invalid = form.querySelector(':invalid');
        invalid.focus();
        showFeedback(feedback, `Please correct the field: ${invalid.name || invalid.id}`, 'error');
        return;
      }
      const phoneVal = form.phone && form.phone.value ? form.phone.value.trim() : '';
      if (!validPhone(phoneVal)) {
        form.phone.focus();
        showFeedback(feedback, 'Phone number format invalid. Use +27... or 0712345678', 'error');
        return;
      }

      // Build payload
      const payload = {
        name: form.name.value.trim(),
        email: form.email.value.trim(),
        phone: phoneVal || null,
        type: form.type && form.type.value ? form.type.value : null,
        message: form.message.value.trim()
      };

      // If endpoint configured, send via AJAX
      if (CONFIG.contactEndpoint) {
        submitJSON(CONFIG.contactEndpoint, payload)
          .then(res => {
            showFeedback(feedback, res.message || 'Message sent successfully.', 'success');
            form.reset();
          })
          .catch(err => {
            console.error(err);
            showFeedback(feedback, 'Failed to send via server. Opening mail client as fallback.', 'error');
            // fallback to mailto
            openMailTo(CONFIG.fallbackMailTo, `Website contact: ${payload.type || 'General'}`, composeBodyFromPayload(payload));
          });
      } else {
        // Fallback: open mail client prepared
        openMailTo(CONFIG.fallbackMailTo, `Website contact: ${payload.type || 'General'}`, composeBodyFromPayload(payload));
        showFeedback(feedback, 'Email prepared in your mail client (fallback).', 'info');
        form.reset();
      }
    });
  }

  function composeBodyFromPayload(payload) {
    const lines = [
      `Name: ${payload.name}`,
      `Email: ${payload.email}`,
      `Phone: ${payload.phone || 'N/A'}`,
      `Message type: ${payload.type || 'N/A'}`,
      '',
      'Message:',
      payload.message
    ];
    return lines.join('\n');
  }

  function openMailTo(to, subject, body) {
    const url = `mailto:${encodeURIComponent(to)}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    // open in same window; user mail client should handle
    window.location.href = url;
  }

  /* ---------- Enquiry Form ---------- */
  function initEnquiryForm() {
    const form = document.getElementById('enquiryForm');
    if (!form) return;
    const responseBox = document.getElementById('enquiryResponse') || document.createElement('div');
    responseBox.id = 'enquiryResponse';
    form.appendChild(responseBox);

    // dynamic fields are handled in HTML but in case you want to generate them here you could
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      responseBox.innerHTML = '';
      if (!form.checkValidity()) {
        const invalid = form.querySelector(':invalid');
        if (invalid) invalid.focus();
        showFeedback(responseBox, 'Please fill the required fields correctly.', 'error');
        return;
      }

      const typeVal = (document.getElementById('enquiryType') && document.getElementById('enquiryType').value) || '';
      let reply = '';
      let payload = {
        name: (document.getElementById('enquiryName') && document.getElementById('enquiryName').value) || '',
        email: (document.getElementById('enquiryEmail') && document.getElementById('enquiryEmail').value) || '',
        type: typeVal
      };

      if (typeVal === 'product') {
        const pid = (document.getElementById('productSelect') && document.getElementById('productSelect').value) || '';
        const qty = parseInt((document.getElementById('qty') && document.getElementById('qty').value) || '1', 10);
        payload.productId = pid;
        payload.quantity = qty;
        // price list is front-end sample; server should recalc in production
        const samplePrices = { shoe: 200, uniform: 350 };
        const price = samplePrices[pid] || 0;
        const cost = price * qty;
        reply = `Product selected: ${pid}\nQuantity: ${qty}\nEstimated cost: ${CONFIG.currencySymbol}${cost}\nAvailability: In stock (estimate).`;
      } else if (typeVal === 'service') {
        const serv = (document.getElementById('serviceSelect') && document.getElementById('serviceSelect').value) || '';
        payload.service = serv;
        reply = `Service: ${serv}\nWe have limited spaces — we'll contact you to confirm availability.`;
      } else if (typeVal === 'volunteer') {
        const role = (document.getElementById('volRole') && document.getElementById('volRole').value) || '';
        payload.role = role;
        reply = `Volunteer role: ${role}\nThank you! We'll follow up with onboarding details.`;
      } else if (typeVal === 'sponsor') {
        const level = (document.getElementById('sponsorLevel') && document.getElementById('sponsorLevel').value) || '';
        payload.sponsorLevel = level;
        reply = `Sponsorship level: ${level}\nA coordinator will reach out about payment and benefits.`;
      } else {
        reply = 'Please select an enquiry type.';
      }

      // If endpoint configured, send via AJAX
      if (CONFIG.enquiryEndpoint) {
        submitJSON(CONFIG.enquiryEndpoint, payload)
          .then(res => {
            showFeedback(responseBox, res.message || 'Enquiry submitted. We will contact you soon.', 'success');
            // show reply as additional info
            const pre = document.createElement('pre');
            pre.textContent = reply;
            responseBox.appendChild(pre);
            form.reset();
          })
          .catch(err => {
            console.error(err);
            showFeedback(responseBox, 'Failed to submit enquiry to the server. See details below.', 'error');
            const pre = document.createElement('pre');
            pre.textContent = reply;
            responseBox.appendChild(pre);
          });
      } else {
        // No backend: just show the response in a modal or box
        showFeedback(responseBox, 'Local response (no server configured). See details below.', 'info');
        const pre = document.createElement('pre');
        pre.textContent = reply;
        responseBox.appendChild(pre);
        form.reset();
      }
    });
  }

  /* ---------- AJAX / fetch helper ---------- */
  function submitJSON(url, data) {
    // Basic JSON POST, expecting JSON response { success: true, message: '...' }
    return fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
      body: JSON.stringify(data),
      credentials: 'same-origin'
    }).then(async (response) => {
      if (!response.ok) {
        const text = await response.text();
        throw new Error('Network response was not ok: ' + response.status + ' ' + text);
      }
      return response.json().catch(() => ({ message: 'OK' }));
    });
  }

  /* ==========================
     Init all on DOMContentLoaded
     ========================== */
  document.addEventListener('DOMContentLoaded', () => {
    initAccordion();
    initServiceSearch();
    initGallery();
    initDynamicPosts();
    initContactForm();
    initEnquiryForm();
    // small enhancement: keyboard shortcut to close modals/lightbox (Escape)
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        // close any visible lightbox
        const lb = document.getElementById('lightbox');
        if (lb && lb.style.display === 'flex') {
          lb.style.display = 'none';
          lb.setAttribute('aria-hidden', 'true');
        }
      }
    });
  });

})();
