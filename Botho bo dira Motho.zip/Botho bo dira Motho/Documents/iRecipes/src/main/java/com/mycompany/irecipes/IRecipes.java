/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.irecipes;

/**
 *
 * @author RC_Student_lab
 */
public class IRecipes {

    
        // Interface
public interface iRecipes {
    public void PrintRecipes();
}

// Abstract Class
abstract class Recipes implements iRecipes {
    protected String ingredients;
    protected int timeToMake;  // in minutes
    protected String difficultyLevel;

    // Constructor
    public Recipes(String ingredients, int timeToMake, String difficultyLevel) {
        this.ingredients = ingredients;
        this.timeToMake = timeToMake;
        this.difficultyLevel = difficultyLevel;
    }

    // Getter methods
    public String getIngredients() {
        return ingredients;
    }

    public int getTimeToMake() {
        return timeToMake;
    }

    public String getDifficultyLevel() {
        return difficultyLevel;
    }
}

// Subclass
class ProcessRecipes extends Recipes {
    public ProcessRecipes(String ingredients, int timeToMake, String difficultyLevel) {
        super(ingredients, timeToMake, difficultyLevel);
    }

    // Implement interface method
    @Override
    public void PrintRecipes() {
        System.out.println("Recipe Details:");
        System.out.println("Ingredients: " + getIngredients());
        System.out.println("Time to make: " + getTimeToMake() + " minutes");
        System.out.println("Difficulty Level: " + getDifficultyLevel());
    }
}

// Main Application
public class BakingApplication {
    public static void main(String[] args) {
        // Example Recipe
        ProcessRecipes recipe = new ProcessRecipes(
            "Flour, Sugar, Eggs, Butter, Baking Powder",
            45,
            "Medium"
        );

        recipe.PrintRecipes();
    }
}
}
        
